import React, { Component } from 'react';
import './App.css';
import {connect} from 'react-redux';
import Button from '@mui/material/Button';


class App extends Component {
  /*state={
    count:0
  }*/
  increase=()=>{
    const count1 =this.state.count;
    const count=count1+1;
    this.setState({
      count:count
      

    })
  }

  decrease=()=>{
    const count1 =this.state.count;
    const count=count1-1;
    this.setState({
      count:count
      

    })
  }
  render(){
    console.log(this.props)
    return (
    <div className="all">
 <div className="Button">     <Button onClick={this.props.increase}>+ Increase</Button></div>

      <div className="textres">{this.props.count}</div>
      <div className="Button2">     <Button onClick={this.props.decrease}>  - Decrease
</Button></div>

        
    </div>
  );
  }
  
}
function mapStateprops(state){
  return{
    count:state.count
  }
}

const action1={
  type:'INCREASE'
}
const action2={
  type:'DECREASE'
}
function mapDispatchToProps(dispatch){
  return {
    increase:()=>dispatch(action1),
    decrease:()=>dispatch(action2)
  }
}

export default connect(mapStateprops ,mapDispatchToProps) (App);
